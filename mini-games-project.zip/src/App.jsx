import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import TicTacToe from './games/TicTacToe'
import MemoryGame from './games/MemoryGame'
import SnakeGame from './games/SnakeGame'
import RockPaperScissors from './games/RockPaperScissors'
import NumberGuessing from './games/NumberGuessing'
import './App.css'

const games = [
  { id: 'tictactoe', name: 'Tic Tac Toe', component: TicTacToe, description: 'Classic 3x3 grid game' },
  { id: 'memory', name: 'Memory Game', component: MemoryGame, description: 'Match pairs of cards' },
  { id: 'snake', name: 'Snake Game', component: SnakeGame, description: 'Eat food and grow longer' },
  { id: 'rps', name: 'Rock Paper Scissors', component: RockPaperScissors, description: 'Beat the computer' },
  { id: 'number', name: 'Number Guessing', component: NumberGuessing, description: 'Guess the secret number' }
]

function App() {
  const [currentGame, setCurrentGame] = useState(null)

  const GameComponent = currentGame ? games.find(g => g.id === currentGame)?.component : null

  if (GameComponent) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-4">
            <Button onClick={() => setCurrentGame(null)} variant="outline">
              ← Back to Games
            </Button>
          </div>
          <GameComponent />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">Mini Games Collection</h1>
          <p className="text-gray-600">Choose a game to play!</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {games.map((game) => (
            <Card key={game.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <CardTitle>{game.name}</CardTitle>
                <CardDescription>{game.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  onClick={() => setCurrentGame(game.id)}
                  className="w-full"
                >
                  Play Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}

export default App

