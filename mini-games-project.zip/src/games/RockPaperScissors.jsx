import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'

const RockPaperScissors = () => {
  const [playerChoice, setPlayerChoice] = useState(null)
  const [computerChoice, setComputerChoice] = useState(null)
  const [result, setResult] = useState(null)
  const [score, setScore] = useState({ player: 0, computer: 0 })

  const choices = [
    { name: 'rock', emoji: '🪨', beats: 'scissors' },
    { name: 'paper', emoji: '📄', beats: 'rock' },
    { name: 'scissors', emoji: '✂️', beats: 'paper' }
  ]

  const getRandomChoice = () => {
    return choices[Math.floor(Math.random() * choices.length)]
  }

  const determineWinner = (player, computer) => {
    if (player.name === computer.name) return 'tie'
    if (player.beats === computer.name) return 'player'
    return 'computer'
  }

  const playGame = (playerChoice) => {
    const computerChoice = getRandomChoice()
    const winner = determineWinner(playerChoice, computerChoice)
    
    setPlayerChoice(playerChoice)
    setComputerChoice(computerChoice)
    setResult(winner)
    
    if (winner === 'player') {
      setScore(prev => ({ ...prev, player: prev.player + 1 }))
    } else if (winner === 'computer') {
      setScore(prev => ({ ...prev, computer: prev.computer + 1 }))
    }
  }

  const resetGame = () => {
    setPlayerChoice(null)
    setComputerChoice(null)
    setResult(null)
    setScore({ player: 0, computer: 0 })
  }

  const getResultMessage = () => {
    switch (result) {
      case 'player': return 'You win!'
      case 'computer': return 'Computer wins!'
      case 'tie': return "It's a tie!"
      default: return 'Make your choice!'
    }
  }

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-center">Rock Paper Scissors</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center mb-6">
          <div className="text-lg font-semibold mb-2">
            Player: {score.player} | Computer: {score.computer}
          </div>
          <div className="text-lg">{getResultMessage()}</div>
        </div>
        
        {playerChoice && computerChoice && (
          <div className="flex justify-around items-center mb-6">
            <div className="text-center">
              <div className="text-4xl mb-2">{playerChoice.emoji}</div>
              <div className="text-sm">You</div>
            </div>
            <div className="text-2xl">VS</div>
            <div className="text-center">
              <div className="text-4xl mb-2">{computerChoice.emoji}</div>
              <div className="text-sm">Computer</div>
            </div>
          </div>
        )}
        
        <div className="grid grid-cols-3 gap-3 mb-4">
          {choices.map((choice) => (
            <Button
              key={choice.name}
              onClick={() => playGame(choice)}
              variant="outline"
              className="h-20 text-3xl"
            >
              {choice.emoji}
            </Button>
          ))}
        </div>
        
        <div className="text-center text-sm text-gray-600 mb-4">
          Rock beats Scissors • Paper beats Rock • Scissors beats Paper
        </div>
        
        <Button onClick={resetGame} className="w-full">
          Reset Score
        </Button>
      </CardContent>
    </Card>
  )
}

export default RockPaperScissors

