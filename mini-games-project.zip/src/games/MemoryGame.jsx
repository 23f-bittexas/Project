import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'

const MemoryGame = () => {
  const [cards, setCards] = useState([])
  const [flipped, setFlipped] = useState([])
  const [matched, setMatched] = useState([])
  const [moves, setMoves] = useState(0)
  const [gameWon, setGameWon] = useState(false)

  const symbols = ['🎮', '🎯', '🎲', '🎪', '🎨', '🎭', '🎸', '🎺']

  const initializeGame = () => {
    const shuffledCards = [...symbols, ...symbols]
      .sort(() => Math.random() - 0.5)
      .map((symbol, index) => ({ id: index, symbol }))
    
    setCards(shuffledCards)
    setFlipped([])
    setMatched([])
    setMoves(0)
    setGameWon(false)
  }

  useEffect(() => {
    initializeGame()
  }, [])

  useEffect(() => {
    if (matched.length === cards.length && cards.length > 0) {
      setGameWon(true)
    }
  }, [matched, cards])

  const handleCardClick = (id) => {
    if (flipped.length === 2 || flipped.includes(id) || matched.includes(id)) {
      return
    }

    const newFlipped = [...flipped, id]
    setFlipped(newFlipped)

    if (newFlipped.length === 2) {
      setMoves(moves + 1)
      const [first, second] = newFlipped
      const firstCard = cards.find(card => card.id === first)
      const secondCard = cards.find(card => card.id === second)

      if (firstCard.symbol === secondCard.symbol) {
        setMatched([...matched, first, second])
        setFlipped([])
      } else {
        setTimeout(() => setFlipped([]), 1000)
      }
    }
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-center">Memory Game</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center mb-4">
          <p className="text-lg">Moves: {moves}</p>
          {gameWon && <p className="text-green-600 font-semibold">Congratulations! You won!</p>}
        </div>
        
        <div className="grid grid-cols-4 gap-3 mb-4">
          {cards.map((card) => (
            <Button
              key={card.id}
              onClick={() => handleCardClick(card.id)}
              variant="outline"
              className={`h-16 text-2xl ${
                flipped.includes(card.id) || matched.includes(card.id)
                  ? 'bg-blue-100'
                  : 'bg-gray-200'
              }`}
            >
              {flipped.includes(card.id) || matched.includes(card.id)
                ? card.symbol
                : '?'
              }
            </Button>
          ))}
        </div>
        
        <Button onClick={initializeGame} className="w-full">
          New Game
        </Button>
      </CardContent>
    </Card>
  )
}

export default MemoryGame

