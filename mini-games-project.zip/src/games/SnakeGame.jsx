import { useState, useEffect, useCallback } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'

const SnakeGame = () => {
  const [snake, setSnake] = useState([{ x: 10, y: 10 }])
  const [food, setFood] = useState({ x: 15, y: 15 })
  const [direction, setDirection] = useState({ x: 0, y: 0 })
  const [gameOver, setGameOver] = useState(false)
  const [score, setScore] = useState(0)
  const [gameStarted, setGameStarted] = useState(false)

  const gridSize = 20

  const generateFood = useCallback(() => {
    return {
      x: Math.floor(Math.random() * gridSize),
      y: Math.floor(Math.random() * gridSize)
    }
  }, [])

  const resetGame = () => {
    setSnake([{ x: 10, y: 10 }])
    setFood(generateFood())
    setDirection({ x: 0, y: 0 })
    setGameOver(false)
    setScore(0)
    setGameStarted(false)
  }

  const startGame = () => {
    setGameStarted(true)
    setDirection({ x: 1, y: 0 })
  }

  const moveSnake = useCallback(() => {
    if (!gameStarted || gameOver) return

    setSnake(currentSnake => {
      const newSnake = [...currentSnake]
      const head = { ...newSnake[0] }
      
      head.x += direction.x
      head.y += direction.y

      // Check wall collision
      if (head.x < 0 || head.x >= gridSize || head.y < 0 || head.y >= gridSize) {
        setGameOver(true)
        return currentSnake
      }

      // Check self collision
      if (newSnake.some(segment => segment.x === head.x && segment.y === head.y)) {
        setGameOver(true)
        return currentSnake
      }

      newSnake.unshift(head)

      // Check food collision
      if (head.x === food.x && head.y === food.y) {
        setScore(s => s + 10)
        setFood(generateFood())
      } else {
        newSnake.pop()
      }

      return newSnake
    })
  }, [direction, food, gameStarted, gameOver, generateFood])

  useEffect(() => {
    const handleKeyPress = (e) => {
      if (!gameStarted) return
      
      switch (e.key) {
        case 'ArrowUp':
          if (direction.y === 0) setDirection({ x: 0, y: -1 })
          break
        case 'ArrowDown':
          if (direction.y === 0) setDirection({ x: 0, y: 1 })
          break
        case 'ArrowLeft':
          if (direction.x === 0) setDirection({ x: -1, y: 0 })
          break
        case 'ArrowRight':
          if (direction.x === 0) setDirection({ x: 1, y: 0 })
          break
      }
    }

    window.addEventListener('keydown', handleKeyPress)
    return () => window.removeEventListener('keydown', handleKeyPress)
  }, [direction, gameStarted])

  useEffect(() => {
    const gameInterval = setInterval(moveSnake, 150)
    return () => clearInterval(gameInterval)
  }, [moveSnake])

  const renderGrid = () => {
    const grid = []
    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        let cellClass = 'w-4 h-4 border border-gray-300'
        
        if (snake.some(segment => segment.x === x && segment.y === y)) {
          cellClass += ' bg-green-500'
        } else if (food.x === x && food.y === y) {
          cellClass += ' bg-red-500'
        } else {
          cellClass += ' bg-gray-100'
        }
        
        grid.push(<div key={`${x}-${y}`} className={cellClass} />)
      }
    }
    return grid
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-center">Snake Game</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center mb-4">
          <p className="text-lg">Score: {score}</p>
          {gameOver && <p className="text-red-600 font-semibold">Game Over!</p>}
          {!gameStarted && !gameOver && <p className="text-blue-600">Press Start to begin</p>}
        </div>
        
        <div className="flex justify-center mb-4">
          <div className="grid grid-cols-20 gap-0 border-2 border-gray-400">
            {renderGrid()}
          </div>
        </div>
        
        <div className="text-center mb-4">
          <p className="text-sm text-gray-600">Use arrow keys to control the snake</p>
        </div>
        
        <div className="flex gap-2 justify-center">
          {!gameStarted && !gameOver && (
            <Button onClick={startGame}>Start Game</Button>
          )}
          <Button onClick={resetGame}>New Game</Button>
        </div>
      </CardContent>
    </Card>
  )
}

export default SnakeGame

