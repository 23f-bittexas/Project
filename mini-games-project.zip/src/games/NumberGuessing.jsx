import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'

const NumberGuessing = () => {
  const [targetNumber, setTargetNumber] = useState(0)
  const [guess, setGuess] = useState('')
  const [attempts, setAttempts] = useState(0)
  const [message, setMessage] = useState('')
  const [gameWon, setGameWon] = useState(false)
  const [guessHistory, setGuessHistory] = useState([])
  const [range, setRange] = useState({ min: 1, max: 100 })

  const generateNumber = () => {
    return Math.floor(Math.random() * (range.max - range.min + 1)) + range.min
  }

  const startNewGame = () => {
    setTargetNumber(generateNumber())
    setGuess('')
    setAttempts(0)
    setMessage(`Guess a number between ${range.min} and ${range.max}!`)
    setGameWon(false)
    setGuessHistory([])
  }

  useEffect(() => {
    startNewGame()
  }, [range])

  const handleGuess = () => {
    const numGuess = parseInt(guess)
    
    if (isNaN(numGuess) || numGuess < range.min || numGuess > range.max) {
      setMessage(`Please enter a valid number between ${range.min} and ${range.max}`)
      return
    }

    const newAttempts = attempts + 1
    setAttempts(newAttempts)
    
    const newHistory = [...guessHistory, { guess: numGuess, attempt: newAttempts }]
    setGuessHistory(newHistory)

    if (numGuess === targetNumber) {
      setMessage(`🎉 Congratulations! You guessed it in ${newAttempts} attempts!`)
      setGameWon(true)
    } else if (numGuess < targetNumber) {
      setMessage('📈 Too low! Try a higher number.')
    } else {
      setMessage('📉 Too high! Try a lower number.')
    }
    
    setGuess('')
  }

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !gameWon) {
      handleGuess()
    }
  }

  const changeDifficulty = (newRange) => {
    setRange(newRange)
  }

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-center">Number Guessing Game</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <div className="text-center mb-2">
            <span className="text-sm text-gray-600">Difficulty:</span>
          </div>
          <div className="flex gap-2 justify-center">
            <Button
              size="sm"
              variant={range.max === 50 ? "default" : "outline"}
              onClick={() => changeDifficulty({ min: 1, max: 50 })}
            >
              Easy (1-50)
            </Button>
            <Button
              size="sm"
              variant={range.max === 100 ? "default" : "outline"}
              onClick={() => changeDifficulty({ min: 1, max: 100 })}
            >
              Medium (1-100)
            </Button>
            <Button
              size="sm"
              variant={range.max === 200 ? "default" : "outline"}
              onClick={() => changeDifficulty({ min: 1, max: 200 })}
            >
              Hard (1-200)
            </Button>
          </div>
        </div>

        <div className="text-center mb-4">
          <p className="text-lg font-semibold">Attempts: {attempts}</p>
          <p className="text-sm text-gray-600">{message}</p>
        </div>

        {!gameWon && (
          <div className="flex gap-2 mb-4">
            <Input
              type="number"
              value={guess}
              onChange={(e) => setGuess(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={`Enter ${range.min}-${range.max}`}
              min={range.min}
              max={range.max}
            />
            <Button onClick={handleGuess}>Guess</Button>
          </div>
        )}

        {guessHistory.length > 0 && (
          <div className="mb-4">
            <h3 className="text-sm font-semibold mb-2">Guess History:</h3>
            <div className="max-h-32 overflow-y-auto">
              {guessHistory.map((entry, index) => (
                <div key={index} className="text-sm text-gray-600">
                  Attempt {entry.attempt}: {entry.guess}
                  {entry.guess === targetNumber && ' ✅'}
                </div>
              ))}
            </div>
          </div>
        )}

        <Button onClick={startNewGame} className="w-full">
          New Game
        </Button>
      </CardContent>
    </Card>
  )
}

export default NumberGuessing

