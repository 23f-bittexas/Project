import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'

const TicTacToe = () => {
  const [board, setBoard] = useState(Array(9).fill(null))
  const [isXNext, setIsXNext] = useState(true)
  const [winner, setWinner] = useState(null)

  const checkWinner = (squares) => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
      [0, 4, 8], [2, 4, 6] // diagonals
    ]
    
    for (let line of lines) {
      const [a, b, c] = line
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a]
      }
    }
    return null
  }

  const handleClick = (index) => {
    if (board[index] || winner) return
    
    const newBoard = [...board]
    newBoard[index] = isXNext ? 'X' : 'O'
    setBoard(newBoard)
    
    const gameWinner = checkWinner(newBoard)
    if (gameWinner) {
      setWinner(gameWinner)
    } else if (newBoard.every(square => square)) {
      setWinner('Draw')
    } else {
      setIsXNext(!isXNext)
    }
  }

  const resetGame = () => {
    setBoard(Array(9).fill(null))
    setIsXNext(true)
    setWinner(null)
  }

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-center">Tic Tac Toe</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center mb-4">
          {winner ? (
            <p className="text-lg font-semibold">
              {winner === 'Draw' ? "It's a draw!" : `Player ${winner} wins!`}
            </p>
          ) : (
            <p className="text-lg">Player {isXNext ? 'X' : 'O'}'s turn</p>
          )}
        </div>
        
        <div className="grid grid-cols-3 gap-2 mb-4">
          {board.map((square, index) => (
            <Button
              key={index}
              onClick={() => handleClick(index)}
              variant="outline"
              className="h-16 text-2xl font-bold"
            >
              {square}
            </Button>
          ))}
        </div>
        
        <Button onClick={resetGame} className="w-full">
          New Game
        </Button>
      </CardContent>
    </Card>
  )
}

export default TicTacToe

