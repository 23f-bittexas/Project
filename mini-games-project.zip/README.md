# Mini Games Collection

A React-based collection of 5 classic mini-games, perfect for a 2-week professional React development class.

## 🎮 Games Included

1. **Tic Tac Toe** - Classic 3x3 grid game for two players
2. **Memory Game** - Match pairs of emoji cards
3. **Snake Game** - Control the snake to eat food and grow longer
4. **Rock Paper Scissors** - Play against the computer
5. **Number Guessing** - Guess the secret number with multiple difficulty levels

## 🚀 Features

- **Responsive Design** - Works on desktop and mobile devices
- **Modern UI** - Built with Tailwind CSS and shadcn/ui components
- **Game Navigation** - Easy switching between games
- **Score Tracking** - Keep track of wins and attempts
- **Clean Code** - Well-structured React components
- **Professional Styling** - Gradient backgrounds and smooth transitions

## 🛠️ Technology Stack

- **React 18** - Modern React with hooks
- **Vite** - Fast build tool and dev server
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - High-quality UI components
- **Lucide Icons** - Beautiful icons
- **JavaScript (JSX)** - Modern JavaScript syntax

## 📁 Project Structure

```
mini-games-project/
├── public/
├── src/
│   ├── components/
│   │   └── ui/          # shadcn/ui components
│   ├── games/           # Individual game components
│   │   ├── TicTacToe.jsx
│   │   ├── MemoryGame.jsx
│   │   ├── SnakeGame.jsx
│   │   ├── RockPaperScissors.jsx
│   │   └── NumberGuessing.jsx
│   ├── App.jsx          # Main application component
│   ├── App.css          # Global styles
│   └── main.jsx         # Entry point
├── package.json
└── README.md
```

## 🏃‍♂️ Getting Started

### Prerequisites
- Node.js (version 16 or higher)
- npm or pnpm

### Installation

1. Navigate to the project directory:
```bash
cd mini-games-project
```

2. Install dependencies:
```bash
npm install
# or
pnpm install
```

3. Start the development server:
```bash
npm run dev
# or
pnpm run dev
```

4. Open your browser and visit `http://localhost:5173`

### Building for Production

```bash
npm run build
# or
pnpm run build
```

## 🎯 Game Instructions

### Tic Tac Toe
- Click on empty squares to place your mark (X or O)
- Get three in a row horizontally, vertically, or diagonally to win
- Click "New Game" to restart

### Memory Game
- Click cards to flip them and reveal symbols
- Match pairs of identical symbols
- Complete all pairs to win
- Try to minimize the number of moves

### Snake Game
- Use arrow keys to control the snake
- Eat red food to grow longer and increase score
- Avoid hitting walls or yourself
- Click "Start Game" to begin

### Rock Paper Scissors
- Choose rock, paper, or scissors
- Rock beats scissors, paper beats rock, scissors beats paper
- Score is tracked automatically
- Click "Reset Score" to start over

### Number Guessing
- Choose difficulty level (Easy: 1-50, Medium: 1-100, Hard: 1-200)
- Guess the secret number
- Get hints if your guess is too high or too low
- Try to guess in as few attempts as possible

## 🎨 Customization

The project uses Tailwind CSS for styling, making it easy to customize:

- **Colors**: Modify the gradient backgrounds in `App.jsx`
- **Components**: All games are separate components in the `games/` folder
- **UI Elements**: shadcn/ui components can be customized in `components/ui/`
- **Styling**: Global styles are in `App.css`

## 📚 Learning Objectives

This project demonstrates:

- React functional components and hooks
- State management with useState and useEffect
- Event handling and user interactions
- Component composition and reusability
- Modern CSS with Tailwind
- Game logic implementation
- Responsive design principles
- Project structure and organization

## 🤝 Contributing

This project is designed for educational purposes. Feel free to:

- Add new games
- Improve existing game logic
- Enhance the UI/UX
- Add sound effects
- Implement high score persistence

## 📄 License

This project is created for educational purposes and is free to use and modify.

---

**Perfect for React learning!** This project covers essential React concepts while building something fun and interactive.

